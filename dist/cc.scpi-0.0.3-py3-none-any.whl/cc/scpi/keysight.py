
from .generic_instrument import GenericInstrument

class KeySight33600A(GenericInstrument):
    pass
    